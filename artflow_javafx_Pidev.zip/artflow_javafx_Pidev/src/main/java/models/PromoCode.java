package models;

public class PromoCode {
    int id;
    String code;
}
